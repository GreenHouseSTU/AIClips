# AIClips-2.0---Slicetube-Clone
Revised AIClips focused on functionality
